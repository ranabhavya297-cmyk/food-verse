import React, { useEffect, useState } from "react";
import { api } from "./api.js";
import Analyzer from "./components/Analyzer.jsx";
import History from "./components/History.jsx";
import MealPlanner from "./components/MealPlanner.jsx";
import Profile from "./components/Profile.jsx";

const NAV = [
  { id: "food", icon: "🍛", label: "Food & Nutrition" },
  { id: "freshness", icon: "🥬", label: "Freshness Check" },
  { id: "hygiene", icon: "🧼", label: "Hygiene Monitor" },
  { id: "cooking", icon: "👩‍🍳", label: "Cooking Assistant" },
  { id: "mealplan", icon: "📅", label: "Meal Planner" },
  { id: "history", icon: "🗂", label: "History" },
  { id: "profile", icon: "🧑‍🍳", label: "Profile" },
];

const PAGES = {
  food: (
    <Analyzer
      kind="food"
      icon="🍛"
      title="Food Recognition & Nutrition Analysis"
      subtitle="Snap a meal. Get dish name, portions, calories, macros and how it fits your diet."
      textLabel="Optional: describe the meal or ask a question"
      textPlaceholder="e.g. Home-cooked lunch, about 1 cup rice and dal. Is it okay for diabetes?"
      samples={["Is this good for weight loss?", "Estimate calories for one serving"]}
    />
  ),
  freshness: (
    <Analyzer
      kind="freshness"
      icon="🥬"
      title="Food Freshness & Spoilage Detection"
      subtitle="Check fruits, vegetables, meat, dairy or leftovers for signs of spoilage."
      textLabel="Optional: how was it stored, and for how long?"
      textPlaceholder="e.g. Chicken kept in the fridge for 3 days, smells slightly sour"
      samples={["Stored in fridge for 4 days", "Left on counter overnight"]}
    />
  ),
  hygiene: (
    <Analyzer
      kind="hygiene"
      icon="🧼"
      title="Restaurant Hygiene & Safety Monitoring"
      subtitle="Upload kitchen photos or a short video. FoodVerse AI reviews cleanliness, handling and cross-contamination risks."
      textLabel="Optional: area being reviewed"
      textPlaceholder="e.g. Prep area during dinner rush, tandoor section"
      samples={["Main prep area", "Storage and refrigeration"]}
    />
  ),
  cooking: (
    <Analyzer
      kind="cooking"
      icon="👩‍🍳"
      needsMedia={false}
      title="Smart Cooking Assistance"
      subtitle="Tell or show what you have. Get a recipe tailored to your profile, with substitutions and tips."
      textLabel="What do you want to cook?"
      textPlaceholder="e.g. I have eggs, spinach and bread. Something high protein in 15 minutes."
      samples={["Use up leftover rice", "Healthy dinner with paneer", "Quick breakfast under 10 minutes"]}
    />
  ),
  mealplan: <MealPlanner />,
  history: <History />,
  profile: <Profile />,
};

export default function App() {
  const [page, setPage] = useState("food");
  const [health, setHealth] = useState(null);
  const [menu, setMenu] = useState(false);

  useEffect(() => {
    api.health().then(setHealth).catch(() => setHealth({ status: "down" }));
  }, []);

  return (
    <div className="shell">
      <button className="burger" onClick={() => setMenu(!menu)}>☰</button>
      <aside className={`sidebar ${menu ? "open" : ""}`}>
        <div className="brand">
          <span className="logo pulse">🥗</span>
          <div>
            <b>FoodVerse AI</b>
            <small>Multimodal Food Intelligence</small>
          </div>
        </div>
        <nav>
          {NAV.map((n, i) => (
            <button
              key={n.id}
              className={`nav-item ${page === n.id ? "active" : ""}`}
              style={{ animationDelay: `${i * 50}ms` }}
              onClick={() => { setPage(n.id); setMenu(false); }}
            >
              <span>{n.icon}</span> {n.label}
            </button>
          ))}
        </nav>
        <div className="status">
          {health === null && "Connecting…"}
          {health?.status === "ok" && (
            <>
              <span className="dot ok" /> API online
              {health.demo_mode && <div className="demo-note">Demo mode (no API key)</div>}
            </>
          )}
          {health?.status === "down" && (<><span className="dot bad" /> Backend offline. Start FastAPI on port 8000.</>)}
        </div>
      </aside>
      <main key={page}>{PAGES[page]}</main>
    </div>
  );
}
