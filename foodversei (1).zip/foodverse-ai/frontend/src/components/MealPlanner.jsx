import React, { useState } from "react";
import { api } from "../api.js";
import ResultView from "./ResultView.jsx";

export default function MealPlanner() {
  const [days, setDays] = useState(3);
  const [request, setRequest] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [data, setData] = useState(null);

  async function go() {
    setLoading(true);
    setError("");
    try {
      setData(await api.mealPlan(days, request));
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="page">
      <header className="page-head fade-up">
        <div className="page-icon float">📅</div>
        <div>
          <h2>Personalised Meal Planning</h2>
          <p className="muted">Uses your saved profile (diet, allergies, calorie goal) to build a plan and grocery list.</p>
        </div>
      </header>
      <div className="card input-card fade-up">
        <label className="field">
          <span>Number of days: <b>{days}</b></span>
          <input type="range" min="1" max="7" value={days} onChange={(e) => setDays(+e.target.value)} />
        </label>
        <label className="field">
          <span>Anything specific?</span>
          <textarea rows={3} value={request} onChange={(e) => setRequest(e.target.value)} placeholder="e.g. high protein, quick lunches under 15 minutes, budget friendly…" />
        </label>
        {error && <div className="alert">{error}</div>}
        <button className="btn primary" disabled={loading} onClick={go}>
          {loading ? <><span className="spinner" /> Planning…</> : "Generate meal plan"}
        </button>
      </div>
      {data && <ResultView kind="mealplan" result={data.result} demo={data.demo} />}
    </div>
  );
}
