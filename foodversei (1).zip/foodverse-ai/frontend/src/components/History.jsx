import React, { useEffect, useState } from "react";
import { api } from "../api.js";
import ResultView from "./ResultView.jsx";

const LABELS = { food: "🍛 Food & Nutrition", freshness: "🥬 Freshness", hygiene: "🧼 Hygiene", cooking: "👩‍🍳 Cooking", mealplan: "📅 Meal Plan" };

export default function History() {
  const [items, setItems] = useState([]);
  const [filter, setFilter] = useState("");
  const [open, setOpen] = useState(null);
  const [error, setError] = useState("");

  const load = () => api.history(filter || undefined).then(setItems).catch((e) => setError(e.message));
  useEffect(() => { load(); }, [filter]);

  async function remove(id) {
    await api.deleteHistory(id);
    setItems((x) => x.filter((i) => i.id !== id));
    if (open === id) setOpen(null);
  }

  return (
    <div className="page">
      <header className="page-head fade-up">
        <div className="page-icon float">🗂</div>
        <div>
          <h2>History</h2>
          <p className="muted">Everything you analysed is stored in the backend database.</p>
        </div>
      </header>
      <div className="chips fade-up">
        <button className={`chip chip-btn ${!filter ? "active" : ""}`} onClick={() => setFilter("")}>All</button>
        {Object.entries(LABELS).map(([k, v]) => (
          <button key={k} className={`chip chip-btn ${filter === k ? "active" : ""}`} onClick={() => setFilter(k)}>{v}</button>
        ))}
      </div>
      {error && <div className="alert">{error}</div>}
      {!items.length && <div className="card muted">Nothing here yet. Run an analysis first.</div>}
      {items.map((it, i) => (
        <div key={it.id} className="card history-item fade-up" style={{ animationDelay: `${Math.min(i, 8) * 40}ms` }}>
          <div className="history-row" onClick={() => setOpen(open === it.id ? null : it.id)}>
            {it.thumbnail ? <img src={it.thumbnail} alt="" /> : <div className="thumb-ph">{LABELS[it.kind]?.split(" ")[0]}</div>}
            <div className="grow">
              <b>{LABELS[it.kind] || it.kind}</b>
              <div className="muted small">{new Date(it.created_at).toLocaleString()} {it.demo ? "· demo" : ""}</div>
              {it.input_text && <div className="muted small clip">“{it.input_text}”</div>}
            </div>
            <button className="link-btn danger" onClick={(e) => { e.stopPropagation(); remove(it.id); }}>Delete</button>
          </div>
          {open === it.id && <ResultView kind={it.kind} result={it.result} demo={it.demo} />}
        </div>
      ))}
    </div>
  );
}
