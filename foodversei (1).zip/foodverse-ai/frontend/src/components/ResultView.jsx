import React from "react";
import ScoreRing from "./ScoreRing.jsx";

const Chip = ({ children, tone = "neutral" }) => <span className={`chip chip-${tone}`}>{children}</span>;
const List = ({ items }) =>
  items && items.length ? (
    <ul className="plain-list">
      {items.map((x, i) => (
        <li key={i}>{x}</li>
      ))}
    </ul>
  ) : null;

function Macro({ label, value, unit = "g", tone }) {
  return (
    <div className={`macro ${tone || ""}`}>
      <b>{Math.round(value ?? 0)}</b>
      <span>
        {unit} {label}
      </span>
    </div>
  );
}

function Food({ r }) {
  const t = r.totals || {};
  return (
    <>
      <div className="result-head">
        <ScoreRing value={r.health_score} label="Health" />
        <div>
          <h3>{r.dish_name}</h3>
          <p className="muted">Confidence {Math.round(r.confidence ?? 0)}%</p>
          <div className="chips">{(r.allergen_flags || []).map((a) => <Chip key={a} tone="warn">⚠ {a}</Chip>)}</div>
        </div>
      </div>
      <div className="macros">
        <Macro label="kcal" value={t.calories} unit="" tone="cal" />
        <Macro label="protein" value={t.protein_g} />
        <Macro label="carbs" value={t.carbs_g} />
        <Macro label="fat" value={t.fat_g} />
        <Macro label="fibre" value={t.fiber_g} />
      </div>
      <table className="tbl">
        <thead>
          <tr><th>Item</th><th>Portion</th><th>kcal</th><th>P</th><th>C</th><th>F</th></tr>
        </thead>
        <tbody>
          {(r.items || []).map((it, i) => (
            <tr key={i}>
              <td>{it.name}</td><td>{it.portion}</td><td>{it.calories}</td>
              <td>{it.protein_g}</td><td>{it.carbs_g}</td><td>{it.fat_g}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {r.diet_fit && <Section title="Fit with your profile"><p>{r.diet_fit}</p></Section>}
      <Section title="Suggestions"><List items={r.suggestions} /></Section>
    </>
  );
}

function Freshness({ r }) {
  const tone = { fresh: "good", use_soon: "warn", spoiled: "bad", uncertain: "neutral" }[r.status] || "neutral";
  return (
    <>
      <div className="result-head">
        <ScoreRing value={r.freshness_score} label="Fresh" />
        <div>
          <h3>{r.item}</h3>
          <Chip tone={tone}>{(r.status || "").replace("_", " ").toUpperCase()}</Chip>
          <p className="muted">Shelf life: {r.shelf_life_estimate}</p>
        </div>
      </div>
      {r.safety_warning && <div className="alert">🚫 {r.safety_warning}</div>}
      <Section title="What the AI looked at">
        <div className="indicators">
          {(r.indicators || []).map((ind, i) => (
            <div key={i} className={`indicator ind-${ind.concern}`}>
              <b>{ind.sign}</b>
              <span>{ind.observation}</span>
            </div>
          ))}
        </div>
      </Section>
      <Section title="Storage tips"><List items={r.storage_tips} /></Section>
    </>
  );
}

function Hygiene({ r }) {
  const tone = { low: "good", medium: "warn", high: "bad" }[r.risk_level] || "neutral";
  return (
    <>
      <div className="result-head">
        <ScoreRing value={r.hygiene_score} label="Hygiene" />
        <div>
          <h3>Risk level: <Chip tone={tone}>{(r.risk_level || "").toUpperCase()}</Chip></h3>
          <p>{r.summary}</p>
        </div>
      </div>
      <Section title={`Issues found (${(r.violations || []).length})`}>
        {(r.violations || []).map((v, i) => (
          <div key={i} className={`violation sev-${v.severity}`}>
            <div><Chip tone={v.severity === "critical" ? "bad" : v.severity === "major" ? "warn" : "neutral"}>{v.severity}</Chip> <b>{v.issue}</b></div>
            <p className="muted">Fix: {v.recommendation}</p>
          </div>
        ))}
      </Section>
      <Section title="Good practices observed"><List items={r.good_practices} /></Section>
      {r.disclaimer && <p className="fineprint">{r.disclaimer}</p>}
    </>
  );
}

function Cooking({ r }) {
  const n = r.nutrition_per_serving || {};
  return (
    <>
      <div className="result-head">
        <div>
          <h3>{r.title}</h3>
          <p>{r.summary}</p>
          <div className="chips">
            <Chip>⏱ {r.time_minutes} min</Chip>
            <Chip>🍽 {r.servings} servings</Chip>
            {n.calories != null && <Chip>{n.calories} kcal/serving</Chip>}
          </div>
        </div>
      </div>
      <div className="two-col">
        <Section title="Ingredients">
          <ul className="plain-list">
            {(r.ingredients || []).map((i, k) => (
              <li key={k}><b>{i.quantity}</b> {i.name}</li>
            ))}
          </ul>
        </Section>
        <Section title="Steps">
          <ol className="steps">
            {(r.steps || []).map((s, i) => <li key={i}>{s}</li>)}
          </ol>
        </Section>
      </div>
      <Section title="Substitutions"><List items={r.substitutions} /></Section>
      <Section title="Tips"><List items={r.tips} /></Section>
    </>
  );
}

function MealPlan({ r }) {
  return (
    <>
      <h3>{r.title}</h3>
      <div className="days">
        {(r.days || []).map((d, i) => (
          <div className="day" key={i} style={{ animationDelay: `${i * 80}ms` }}>
            <h4>{d.day} <span className="muted">· {d.total_calories} kcal</span></h4>
            {(d.meals || []).map((m, j) => (
              <div className="meal" key={j}>
                <span className="meal-type">{m.type}</span>
                <div><b>{m.name}</b> <span className="muted">{m.calories} kcal</span>{m.notes && <div className="muted small">{m.notes}</div>}</div>
              </div>
            ))}
          </div>
        ))}
      </div>
      <Section title="Grocery list">
        <div className="chips">{(r.grocery_list || []).map((g) => <Chip key={g}>{g}</Chip>)}</div>
      </Section>
      <Section title="Notes"><List items={r.notes} /></Section>
    </>
  );
}

function Section({ title, children }) {
  return (
    <div className="section">
      <h4>{title}</h4>
      {children}
    </div>
  );
}

export default function ResultView({ kind, result, demo }) {
  if (!result) return null;
  const Comp = { food: Food, freshness: Freshness, hygiene: Hygiene, cooking: Cooking, mealplan: MealPlan }[kind];
  return (
    <div className="card result fade-up">
      {demo && <div className="demo-badge">DEMO DATA · add ANTHROPIC_API_KEY for real analysis</div>}
      {Comp ? <Comp r={result} /> : <pre>{JSON.stringify(result, null, 2)}</pre>}
    </div>
  );
}
