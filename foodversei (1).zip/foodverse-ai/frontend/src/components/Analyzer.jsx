import React, { useEffect, useRef, useState } from "react";
import { api } from "../api.js";
import { createVoiceInput, downscaleImage, extractFrames } from "../utils/media.js";
import ResultView from "./ResultView.jsx";

/** Generic multimodal input page: image / video / voice / text -> backend -> result. */
export default function Analyzer({ kind, title, subtitle, icon, textLabel, textPlaceholder, needsMedia = true, samples = [] }) {
  const [files, setFiles] = useState([]); // File[] (images or one video)
  const [previews, setPreviews] = useState([]);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [stage, setStage] = useState("");
  const [error, setError] = useState("");
  const [data, setData] = useState(null);
  const [listening, setListening] = useState(false);
  const [drag, setDrag] = useState(false);
  const recRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    const urls = files.map((f) => ({ url: URL.createObjectURL(f), video: f.type.startsWith("video/") }));
    setPreviews(urls);
    return () => urls.forEach((u) => URL.revokeObjectURL(u.url));
  }, [files]);

  useEffect(() => () => recRef.current && recRef.current.stop(), []);

  function addFiles(list) {
    const arr = Array.from(list || []);
    const video = arr.find((f) => f.type.startsWith("video/"));
    if (video) return setFiles([video]);
    setFiles((prev) => [...prev.filter((f) => f.type.startsWith("image/")), ...arr.filter((f) => f.type.startsWith("image/"))].slice(0, 6));
  }

  function toggleVoice() {
    if (listening) {
      recRef.current && recRef.current.stop();
      return;
    }
    const base = text ? text + " " : "";
    const rec = createVoiceInput({
      onText: (t) => setText(base + t),
      onEnd: () => setListening(false),
      onError: (e) => {
        setError(`Voice input error: ${e}`);
        setListening(false);
      },
    });
    if (!rec) return setError("Voice input is not supported in this browser. Try Chrome or Edge.");
    recRef.current = rec;
    rec.start();
    setListening(true);
  }

  async function submit() {
    setError("");
    if (needsMedia && !files.length && !text.trim()) return setError("Add a photo, a video, or describe the food first.");
    if (!needsMedia && !files.length && !text.trim()) return setError("Type or speak your request first.");
    setLoading(true);
    try {
      let upload = [];
      for (const f of files) {
        if (f.type.startsWith("video/")) {
          setStage("Extracting video frames…");
          upload.push(...(await extractFrames(f, 4)));
        } else {
          upload.push(await downscaleImage(f));
        }
      }
      setStage("AI is analysing…");
      const res = await api.analyze(kind, upload, text);
      setData(res);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
      setStage("");
    }
  }

  return (
    <div className="page">
      <header className="page-head fade-up">
        <div className="page-icon float">{icon}</div>
        <div>
          <h2>{title}</h2>
          <p className="muted">{subtitle}</p>
        </div>
      </header>

      <div className="card input-card fade-up">
        <div
          className={`dropzone ${drag ? "drag" : ""} ${loading ? "scanning" : ""}`}
          onClick={() => inputRef.current.click()}
          onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
          onDragLeave={() => setDrag(false)}
          onDrop={(e) => { e.preventDefault(); setDrag(false); addFiles(e.dataTransfer.files); }}
        >
          {previews.length ? (
            <div className="previews">
              {previews.map((p, i) =>
                p.video ? <video key={i} src={p.url} muted controls onClick={(e) => e.stopPropagation()} /> : <img key={i} src={p.url} alt="" />
              )}
            </div>
          ) : (
            <div className="dz-empty">
              <div className="dz-icon">📷</div>
              <b>Drop image or video here, or click to upload</b>
              <span className="muted">JPG · PNG · WEBP · MP4 / MOV (frames are extracted in your browser)</span>
            </div>
          )}
          {loading && <div className="scan-line" />}
          <input ref={inputRef} type="file" accept="image/*,video/*" capture={undefined} multiple hidden onChange={(e) => addFiles(e.target.files)} />
        </div>
        {files.length > 0 && (
          <button className="link-btn" onClick={() => setFiles([])}>✕ Clear media</button>
        )}

        <label className="field">
          <span>{textLabel}</span>
          <div className="text-row">
            <textarea rows={3} value={text} onChange={(e) => setText(e.target.value)} placeholder={textPlaceholder} />
            <button className={`mic ${listening ? "on" : ""}`} onClick={toggleVoice} title="Voice input" type="button">
              {listening ? "■" : "🎙"}
            </button>
          </div>
        </label>

        {samples.length > 0 && (
          <div className="chips">
            {samples.map((s) => (
              <button key={s} className="chip chip-btn" onClick={() => setText(s)}>{s}</button>
            ))}
          </div>
        )}

        {error && <div className="alert">{error}</div>}
        <button className="btn primary" disabled={loading} onClick={submit}>
          {loading ? <><span className="spinner" /> {stage || "Working…"}</> : "Analyse with FoodVerse AI"}
        </button>
      </div>

      {loading && !data && <div className="card skeleton-card"><div className="skeleton" /><div className="skeleton short" /><div className="skeleton" /></div>}
      {data && <ResultView kind={kind} result={data.result} demo={data.demo} />}
    </div>
  );
}
