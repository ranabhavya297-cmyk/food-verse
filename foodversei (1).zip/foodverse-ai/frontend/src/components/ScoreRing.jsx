import React from "react";

export default function ScoreRing({ value = 0, label = "Score", invert = false }) {
  const v = Math.max(0, Math.min(100, Number(value) || 0));
  const r = 46;
  const c = 2 * Math.PI * r;
  const good = invert ? 100 - v : v;
  const color = good >= 75 ? "var(--good)" : good >= 50 ? "var(--warn)" : "var(--bad)";
  return (
    <div className="ring">
      <svg viewBox="0 0 120 120" width="120" height="120">
        <circle cx="60" cy="60" r={r} className="ring-bg" />
        <circle
          cx="60"
          cy="60"
          r={r}
          className="ring-fg"
          style={{ stroke: color, strokeDasharray: c, "--target": c * (1 - v / 100) }}
          transform="rotate(-90 60 60)"
        />
        <text x="60" y="58" textAnchor="middle" className="ring-num">
          {Math.round(v)}
        </text>
        <text x="60" y="76" textAnchor="middle" className="ring-label">
          {label}
        </text>
      </svg>
    </div>
  );
}
