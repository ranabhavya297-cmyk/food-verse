import React, { useEffect, useState } from "react";
import { api } from "../api.js";

const DIETS = ["No restriction", "Vegetarian", "Vegan", "Eggetarian", "Jain", "Keto", "Low carb", "High protein", "Diabetic friendly", "Gluten free"];
const GOALS = ["Maintain weight", "Lose weight", "Gain muscle", "Eat healthier", "Manage blood sugar"];

export default function Profile() {
  const [p, setP] = useState(null);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => { api.getProfile().then(setP).catch((e) => setError(e.message)); }, []);
  if (!p) return <div className="page">{error ? <div className="alert">{error}</div> : <div className="skeleton" />}</div>;

  const set = (k) => (e) => { setSaved(false); setP({ ...p, [k]: e.target.value }); };

  async function save() {
    try {
      setP(await api.saveProfile({ ...p, calorie_goal: Number(p.calorie_goal) || 2000 }));
      setSaved(true);
    } catch (e) { setError(e.message); }
  }

  return (
    <div className="page">
      <header className="page-head fade-up">
        <div className="page-icon float">🧑‍🍳</div>
        <div>
          <h2>Your Profile</h2>
          <p className="muted">Personalises nutrition feedback, recipes and meal plans. You control this data and can change it any time.</p>
        </div>
      </header>
      <div className="card input-card fade-up">
        <label className="field"><span>Name</span><input value={p.name} onChange={set("name")} /></label>
        <label className="field"><span>Diet</span>
          <select value={p.diet} onChange={set("diet")}>{DIETS.map((d) => <option key={d}>{d}</option>)}</select>
        </label>
        <label className="field"><span>Allergies / foods to avoid</span><input value={p.allergies} onChange={set("allergies")} placeholder="e.g. peanuts, shellfish" /></label>
        <label className="field"><span>Daily calorie goal</span><input type="number" value={p.calorie_goal} onChange={set("calorie_goal")} /></label>
        <label className="field"><span>Goal</span>
          <select value={p.goal} onChange={set("goal")}>{GOALS.map((d) => <option key={d}>{d}</option>)}</select>
        </label>
        <label className="field"><span>Preferred cuisine</span><input value={p.cuisine} onChange={set("cuisine")} /></label>
        {error && <div className="alert">{error}</div>}
        <button className="btn primary" onClick={save}>Save profile</button>
        {saved && <span className="saved">✓ Saved</span>}
      </div>
    </div>
  );
}
