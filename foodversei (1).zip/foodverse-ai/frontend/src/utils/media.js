// Browser-side media helpers: video -> frames, image downscaling, voice input.

function canvasToBlob(canvas, quality = 0.8) {
  return new Promise((resolve) => canvas.toBlob(resolve, "image/jpeg", quality));
}

/** Extract `count` evenly spaced JPEG frames from a video File. */
export async function extractFrames(file, count = 4, maxSide = 900) {
  const url = URL.createObjectURL(file);
  const video = document.createElement("video");
  video.muted = true;
  video.playsInline = true;
  video.src = url;
  await new Promise((res, rej) => {
    video.onloadedmetadata = res;
    video.onerror = () => rej(new Error("Could not read video file"));
  });
  const dur = video.duration || 1;
  const scale = Math.min(1, maxSide / Math.max(video.videoWidth, video.videoHeight));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(video.videoWidth * scale);
  canvas.height = Math.round(video.videoHeight * scale);
  const ctx = canvas.getContext("2d");
  const frames = [];
  for (let i = 0; i < count; i++) {
    const t = (dur * (i + 0.5)) / count;
    await new Promise((res) => {
      video.onseeked = res;
      video.currentTime = t;
    });
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const blob = await canvasToBlob(canvas);
    frames.push(new File([blob], `frame-${i + 1}.jpg`, { type: "image/jpeg" }));
  }
  URL.revokeObjectURL(url);
  return frames;
}

/** Downscale a large image File to keep uploads small. */
export async function downscaleImage(file, maxSide = 1400) {
  if (!file.type.startsWith("image/") || file.type === "image/gif") return file;
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
  if (scale === 1 && file.size < 2 * 1024 * 1024) return file;
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(bitmap.width * scale);
  canvas.height = Math.round(bitmap.height * scale);
  canvas.getContext("2d").drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  const blob = await canvasToBlob(canvas, 0.85);
  return new File([blob], file.name.replace(/\.\w+$/, "") + ".jpg", { type: "image/jpeg" });
}

/** Voice input via the Web Speech API (Chrome/Edge/Safari). Returns controller or null. */
export function createVoiceInput({ lang = "en-IN", onText, onEnd, onError }) {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return null;
  const rec = new SR();
  rec.lang = lang;
  rec.interimResults = true;
  rec.continuous = true;
  rec.onresult = (e) => {
    let text = "";
    for (let i = 0; i < e.results.length; i++) text += e.results[i][0].transcript;
    onText(text);
  };
  rec.onend = () => onEnd && onEnd();
  rec.onerror = (e) => onError && onError(e.error);
  return rec;
}
