const BASE = "/api";

async function handle(res) {
  if (!res.ok) {
    let msg = `Request failed (${res.status})`;
    try {
      const j = await res.json();
      if (j.detail) msg = typeof j.detail === "string" ? j.detail : JSON.stringify(j.detail);
    } catch {}
    throw new Error(msg);
  }
  return res.json();
}

export const api = {
  health: () => fetch(`${BASE}/health`).then(handle),
  analyze: (kind, files, text) => {
    const fd = new FormData();
    files.forEach((f, i) => fd.append("files", f, f.name || `frame-${i}.jpg`));
    fd.append("text", text || "");
    return fetch(`${BASE}/analyze/${kind}`, { method: "POST", body: fd }).then(handle);
  },
  mealPlan: (days, request) => {
    const fd = new FormData();
    fd.append("days", days);
    fd.append("request", request || "");
    return fetch(`${BASE}/meal-plan`, { method: "POST", body: fd }).then(handle);
  },
  history: (kind) => fetch(`${BASE}/history${kind ? `?kind=${kind}` : ""}`).then(handle),
  deleteHistory: (id) => fetch(`${BASE}/history/${id}`, { method: "DELETE" }).then(handle),
  getProfile: () => fetch(`${BASE}/profile`).then(handle),
  saveProfile: (p) =>
    fetch(`${BASE}/profile`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(p),
    }).then(handle),
};
