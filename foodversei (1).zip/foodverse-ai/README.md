# FoodVerse AI — Multimodal Food Intelligence Agent

FoodVerse AI is a modular, multimodal food intelligence platform. It combines computer vision, video analysis and LLM reasoning to give real-time insight across:

| Module | What it does |
|---|---|
| 🍛 Food Recognition & Nutrition | Identifies dishes, estimates portions, calories and macros, flags allergens, checks fit with your diet |
| 🥬 Freshness & Spoilage Detection | Scores freshness from visual signs, estimates shelf life, gives storage tips and safety warnings |
| 🧼 Restaurant Hygiene & Safety | Reviews kitchen photos or video frames for hygiene issues, risk level and fixes |
| 👩‍🍳 Smart Cooking Assistance | Recipes from your ingredients/photos/voice, with substitutions and tips |
| 📅 Personalised Meal Planning | Multi-day plans and grocery lists based on your profile |

## Architecture (matches the project diagram)

```
React Frontend (Vite)  ──►  FastAPI Backend  ──►  AI Models (Claude vision + LLM)
   image / video / voice /        │
   text input                     └──►  SQLite (history + profile)
```

- **User input**: images, video (4 frames are extracted in the browser), voice (browser Web Speech API → text) and text queries.
- **AI models**: Claude (vision + language) via the Anthropic API, returning structured JSON per module.
- **Storage**: SQLite database (`backend/foodverse.db`) stores history, thumbnails and your profile.
- **Demo mode**: with no API key the app returns realistic sample data so you can explore the UI immediately.

## Project structure

```
foodverse-ai/
├── backend/
│   ├── main.py            # FastAPI routes
│   ├── ai_service.py      # Claude calls + demo fallback
│   ├── prompts.py         # prompts, JSON schemas, demo data
│   ├── database.py        # SQLAlchemy models (history, profile)
│   ├── requirements.txt
│   └── .env.example
└── frontend/
    ├── index.html
    ├── package.json
    ├── vite.config.js     # proxies /api → http://127.0.0.1:8000
    └── src/
        ├── App.jsx, main.jsx, api.js, styles.css   # CSS animations live here
        ├── utils/media.js          # video→frames, image downscale, voice input
        └── components/             # Analyzer, ResultView, ScoreRing, MealPlanner, History, Profile
```

## Run it

Requirements: Python 3.10+ and Node.js 18+.

### 1. Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env              # Windows: copy .env.example .env
# edit .env and set ANTHROPIC_API_KEY=your_key  (leave empty for demo mode)
uvicorn main:app --reload --port 8000
```

API docs: http://127.0.0.1:8000/docs

### 2. Frontend (new terminal)

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173

## API summary

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | status + demo mode flag |
| POST | `/api/analyze/{food\|freshness\|hygiene\|cooking}` | multipart: `files[]` (images), `text` |
| POST | `/api/meal-plan` | form: `days`, `request` |
| GET | `/api/history?kind=` | saved analyses |
| DELETE | `/api/history/{id}` | remove one |
| GET / PUT | `/api/profile` | diet, allergies, calorie goal… |

## Important notes

- Results are AI **estimates**. Calorie numbers are approximate, freshness scores are not lab tests, and hygiene reviews do not replace official inspections. When food safety is in doubt, discard the food.
- Uploaded images are sent to the Anthropic API for analysis when a key is configured. Don't upload images with people's faces or private information.
- Voice input uses the browser's built-in speech recognition (works best in Chrome/Edge) and depends on the browser vendor's speech service.
- Set `ANTHROPIC_MODEL` in `.env` if you want a different Claude model.

## Ideas to extend

Barcode/label scanning, a vector database of recipes (RAG), user accounts (JWT), live camera streaming for hygiene alerts, an exportable PDF report, and a Docker Compose setup.
