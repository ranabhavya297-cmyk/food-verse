"""System prompts and JSON schemas for each FoodVerse AI module."""

BASE_RULES = """You are FoodVerse AI, a multimodal food intelligence agent.
Rules:
- Respond with ONE valid JSON object only. No markdown, no code fences, no commentary.
- Be honest about uncertainty. Visual analysis is an estimate, not a lab test or official inspection.
- Respect the user profile (diet, allergies, goals) when it is provided.
- Never invent details that are not visible or stated; use lower confidence instead."""

PROMPTS = {
    "food": BASE_RULES
    + """
Task: Identify the food in the image(s)/description and estimate nutrition.
JSON schema:
{
  "dish_name": str,
  "confidence": number 0-100,
  "items": [{"name": str, "portion": str, "calories": number, "protein_g": number, "carbs_g": number, "fat_g": number}],
  "totals": {"calories": number, "protein_g": number, "carbs_g": number, "fat_g": number, "fiber_g": number},
  "health_score": number 0-100,
  "diet_fit": str (how it fits the user's diet/allergies/goal),
  "allergen_flags": [str],
  "suggestions": [str]
}""",
    "freshness": BASE_RULES
    + """
Task: Assess freshness/spoilage of the food shown (colour, texture, mould, bruising, slime, wilting, etc.).
JSON schema:
{
  "item": str,
  "freshness_score": number 0-100 (100 = perfectly fresh),
  "status": "fresh" | "use_soon" | "spoiled" | "uncertain",
  "indicators": [{"sign": str, "observation": str, "concern": "none"|"low"|"high"}],
  "shelf_life_estimate": str,
  "storage_tips": [str],
  "safety_warning": str (empty string if none; if unsure advise discarding)
}""",
    "hygiene": BASE_RULES
    + """
Task: Review the kitchen / restaurant / food-handling scene (images or video frames) for hygiene and food-safety practices
(gloves, hairnets, clean surfaces, cross-contamination, pests, storage, temperature control, waste handling, handwashing).
JSON schema:
{
  "hygiene_score": number 0-100,
  "risk_level": "low" | "medium" | "high",
  "violations": [{"issue": str, "severity": "minor"|"major"|"critical", "recommendation": str}],
  "good_practices": [str],
  "summary": str,
  "disclaimer": "This is an AI-assisted visual review and does not replace an official inspection."
}""",
    "cooking": BASE_RULES
    + """
Task: Act as a smart cooking assistant. Use the user's query, any ingredient photos, and their profile.
Give a practical recipe or guidance.
JSON schema:
{
  "title": str,
  "summary": str,
  "time_minutes": number,
  "servings": number,
  "ingredients": [{"name": str, "quantity": str, "have": boolean|null}],
  "steps": [str],
  "substitutions": [str],
  "tips": [str],
  "nutrition_per_serving": {"calories": number, "protein_g": number, "carbs_g": number, "fat_g": number}
}""",
    "mealplan": BASE_RULES
    + """
Task: Create a personalised meal plan using the user's profile and request.
JSON schema:
{
  "title": str,
  "days": [{"day": str, "meals": [{"type": "Breakfast"|"Lunch"|"Snack"|"Dinner", "name": str, "calories": number, "notes": str}], "total_calories": number}],
  "grocery_list": [str],
  "notes": [str]
}""",
}

# ---------- Demo-mode responses (used when ANTHROPIC_API_KEY is not set) ----------
DEMO = {
    "food": {
        "dish_name": "Paneer Butter Masala with Roti (demo)",
        "confidence": 82,
        "items": [
            {"name": "Paneer butter masala", "portion": "1 cup (~220 g)", "calories": 380, "protein_g": 16, "carbs_g": 14, "fat_g": 29},
            {"name": "Whole wheat roti", "portion": "2 pieces", "calories": 210, "protein_g": 7, "carbs_g": 40, "fat_g": 3},
        ],
        "totals": {"calories": 590, "protein_g": 23, "carbs_g": 54, "fat_g": 32, "fiber_g": 7},
        "health_score": 62,
        "diet_fit": "Vegetarian friendly. Contains dairy. Moderate fat; fine within a 2000 kcal plan.",
        "allergen_flags": ["Dairy", "Gluten", "Tree nuts (possible, cashew gravy)"],
        "suggestions": ["Add a cucumber-tomato salad for fibre.", "Ask for less butter/cream to cut ~100 kcal."],
    },
    "freshness": {
        "item": "Tomatoes (demo)",
        "freshness_score": 71,
        "status": "use_soon",
        "indicators": [
            {"sign": "Skin texture", "observation": "Slight wrinkling near the stem", "concern": "low"},
            {"sign": "Colour", "observation": "Even deep red, no dark patches", "concern": "none"},
            {"sign": "Mould", "observation": "None visible", "concern": "none"},
        ],
        "shelf_life_estimate": "2-3 days at room temperature, up to 5 days refrigerated",
        "storage_tips": ["Keep away from direct sunlight.", "Use the softest ones first for gravies or sauces."],
        "safety_warning": "",
    },
    "hygiene": {
        "hygiene_score": 68,
        "risk_level": "medium",
        "violations": [
            {"issue": "Raw and cooked items prepared on the same board", "severity": "major", "recommendation": "Use colour-coded boards and sanitise between tasks."},
            {"issue": "Staff without hairnet", "severity": "minor", "recommendation": "Enforce head covering in the prep area."},
        ],
        "good_practices": ["Clean steel work surfaces", "Gloves used while plating"],
        "summary": "Generally tidy kitchen with cross-contamination risk that should be fixed soon. (demo data)",
        "disclaimer": "This is an AI-assisted visual review and does not replace an official inspection.",
    },
    "cooking": {
        "title": "Quick Veg Fried Rice (demo)",
        "summary": "A 20-minute one-pan meal using leftover rice and vegetables.",
        "time_minutes": 20,
        "servings": 2,
        "ingredients": [
            {"name": "Cooked rice (cold)", "quantity": "2 cups", "have": None},
            {"name": "Mixed vegetables", "quantity": "1 cup", "have": None},
            {"name": "Soy sauce", "quantity": "1.5 tbsp", "have": None},
            {"name": "Garlic", "quantity": "3 cloves", "have": None},
            {"name": "Oil", "quantity": "1.5 tbsp", "have": None},
        ],
        "steps": [
            "Heat oil on high heat and sauté chopped garlic for 20 seconds.",
            "Add vegetables and stir-fry for 3 minutes.",
            "Add cold rice and soy sauce; toss for 4-5 minutes until hot.",
            "Finish with pepper and spring onion. Serve hot.",
        ],
        "substitutions": ["No soy sauce: use a pinch of salt + a few drops of vinegar."],
        "tips": ["Day-old rice gives separate grains.", "Cook on high heat for a smoky flavour."],
        "nutrition_per_serving": {"calories": 340, "protein_g": 8, "carbs_g": 56, "fat_g": 9},
    },
    "mealplan": {
        "title": "3-Day Balanced Plan (demo)",
        "days": [
            {
                "day": f"Day {i}",
                "meals": [
                    {"type": "Breakfast", "name": "Vegetable poha with peanuts", "calories": 350, "notes": "Add lemon for iron absorption"},
                    {"type": "Lunch", "name": "Dal, brown rice, sabzi, salad", "calories": 600, "notes": ""},
                    {"type": "Snack", "name": "Roasted chana + fruit", "calories": 200, "notes": ""},
                    {"type": "Dinner", "name": "Paneer bhurji with 2 rotis", "calories": 520, "notes": ""},
                ],
                "total_calories": 1670,
            }
            for i in range(1, 4)
        ],
        "grocery_list": ["Poha", "Peanuts", "Toor dal", "Brown rice", "Seasonal vegetables", "Paneer", "Whole wheat flour", "Roasted chana", "Fruit"],
        "notes": ["Demo plan. Add your API key for a personalised plan."],
    },
}
