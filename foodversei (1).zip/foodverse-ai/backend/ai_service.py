"""AI service: sends images/text to Claude (vision + LLM) and returns structured JSON.
Falls back to demo data when no API key is configured."""
import base64
import json
import os
import re

from prompts import DEMO, PROMPTS

API_KEY = os.getenv("ANTHROPIC_API_KEY", "").strip()
MODEL = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-5")

_client = None


def is_demo() -> bool:
    return not API_KEY


def _get_client():
    global _client
    if _client is None:
        import anthropic

        _client = anthropic.Anthropic(api_key=API_KEY)
    return _client


def _extract_json(text: str) -> dict:
    text = text.strip()
    text = re.sub(r"^```(?:json)?|```$", "", text, flags=re.MULTILINE).strip()
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1:
        raise ValueError("Model did not return JSON")
    return json.loads(text[start : end + 1])


def run_analysis(kind: str, images: list[tuple[bytes, str]], user_text: str, profile: dict) -> dict:
    """images: list of (raw_bytes, media_type). Returns dict result."""
    if kind not in PROMPTS:
        raise ValueError(f"Unknown analysis kind: {kind}")

    if is_demo():
        return json.loads(json.dumps(DEMO[kind]))

    content = []
    for raw, media_type in images[:8]:
        content.append(
            {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": media_type,
                    "data": base64.b64encode(raw).decode(),
                },
            }
        )
    prompt = f"User profile: {json.dumps(profile)}\n\nUser request / transcript: {user_text or '(none, analyse the image)'}"
    if not images and kind in ("food", "freshness", "hygiene") and not user_text:
        raise ValueError("Please provide an image, video or description.")
    content.append({"type": "text", "text": prompt})

    resp = _get_client().messages.create(
        model=MODEL,
        max_tokens=2500,
        system=PROMPTS[kind],
        messages=[{"role": "user", "content": content}],
    )
    text = "".join(b.text for b in resp.content if getattr(b, "type", "") == "text")
    return _extract_json(text)
