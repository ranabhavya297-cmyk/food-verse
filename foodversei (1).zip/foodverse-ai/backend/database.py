"""Database layer: SQLite via SQLAlchemy. Stores analysis history and the user profile."""
import json
import os
from datetime import datetime

from dotenv import load_dotenv
from sqlalchemy import Column, DateTime, Integer, String, Text, create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./foodverse.db")
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {},
)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()


class Analysis(Base):
    __tablename__ = "analyses"

    id = Column(Integer, primary_key=True, index=True)
    kind = Column(String(32), index=True)  # food | freshness | hygiene | cooking | mealplan
    input_text = Column(Text, default="")
    result_json = Column(Text, nullable=False)
    thumbnail = Column(Text, default="")  # small base64 data URL (optional)
    demo = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "kind": self.kind,
            "input_text": self.input_text,
            "result": json.loads(self.result_json),
            "thumbnail": self.thumbnail,
            "demo": bool(self.demo),
            "created_at": self.created_at.isoformat() + "Z",
        }


class Profile(Base):
    __tablename__ = "profile"

    id = Column(Integer, primary_key=True)
    data_json = Column(Text, default="{}")


DEFAULT_PROFILE = {
    "name": "",
    "diet": "No restriction",
    "allergies": "",
    "calorie_goal": 2000,
    "goal": "Maintain weight",
    "cuisine": "Indian",
}


def init_db():
    Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def load_profile(db) -> dict:
    row = db.get(Profile, 1)
    if not row:
        return dict(DEFAULT_PROFILE)
    return {**DEFAULT_PROFILE, **json.loads(row.data_json or "{}")}


def save_profile(db, data: dict) -> dict:
    merged = {**DEFAULT_PROFILE, **data}
    row = db.get(Profile, 1)
    if not row:
        row = Profile(id=1, data_json=json.dumps(merged))
        db.add(row)
    else:
        row.data_json = json.dumps(merged)
    db.commit()
    return merged
