"""FoodVerse AI - FastAPI backend."""
import base64
import io
import json
import os
from typing import List, Optional

from dotenv import load_dotenv

load_dotenv()

from fastapi import Depends, FastAPI, File, Form, HTTPException, UploadFile  # noqa: E402
from fastapi.middleware.cors import CORSMiddleware  # noqa: E402
from sqlalchemy.orm import Session  # noqa: E402

import ai_service  # noqa: E402
from database import Analysis, get_db, init_db, load_profile, save_profile  # noqa: E402

app = FastAPI(title="FoodVerse AI", version="1.0.0")

origins = [o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_methods=["*"], allow_headers=["*"])

KINDS = {"food", "freshness", "hygiene", "cooking"}
ALLOWED_IMG = {"image/jpeg", "image/png", "image/webp", "image/gif"}
MAX_FILE_BYTES = 8 * 1024 * 1024


@app.on_event("startup")
def _startup():
    init_db()


def _thumbnail(raw: bytes, media_type: str) -> str:
    """Small preview stored with history. Uses Pillow if installed, else skips."""
    try:
        from PIL import Image

        img = Image.open(io.BytesIO(raw)).convert("RGB")
        img.thumbnail((160, 160))
        buf = io.BytesIO()
        img.save(buf, "JPEG", quality=60)
        return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()
    except Exception:
        return ""


async def _read_images(files: List[UploadFile]):
    images = []
    for f in files:
        if f.content_type not in ALLOWED_IMG:
            raise HTTPException(400, f"Unsupported file type: {f.content_type}. Use JPG/PNG/WEBP (videos are converted to frames in the browser).")
        raw = await f.read()
        if len(raw) > MAX_FILE_BYTES:
            raise HTTPException(413, "Image too large (max 8 MB).")
        images.append((raw, f.content_type))
    return images


def _run(kind, images, text, db: Session):
    profile = load_profile(db)
    try:
        result = ai_service.run_analysis(kind, images, text, profile)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:  # API / parsing failures
        raise HTTPException(502, f"AI service error: {e}")
    row = Analysis(
        kind=kind,
        input_text=text or "",
        result_json=json.dumps(result),
        thumbnail=_thumbnail(*images[0]) if images else "",
        demo=1 if ai_service.is_demo() else 0,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row.to_dict()


@app.get("/api/health")
def health():
    return {"status": "ok", "demo_mode": ai_service.is_demo(), "model": ai_service.MODEL}


@app.post("/api/analyze/{kind}")
async def analyze(
    kind: str,
    files: Optional[List[UploadFile]] = File(default=None),
    text: str = Form(default=""),
    db: Session = Depends(get_db),
):
    if kind not in KINDS:
        raise HTTPException(404, "Unknown analysis type")
    images = await _read_images(files or [])
    return _run(kind, images, text, db)


@app.post("/api/meal-plan")
def meal_plan(
    days: int = Form(default=3),
    request: str = Form(default=""),
    db: Session = Depends(get_db),
):
    days = max(1, min(days, 7))
    text = f"Create a {days}-day meal plan. {request}"
    return _run("mealplan", [], text, db)


@app.get("/api/history")
def history(kind: Optional[str] = None, limit: int = 50, db: Session = Depends(get_db)):
    q = db.query(Analysis).order_by(Analysis.created_at.desc())
    if kind:
        q = q.filter(Analysis.kind == kind)
    return [r.to_dict() for r in q.limit(min(limit, 200)).all()]


@app.delete("/api/history/{item_id}")
def delete_history(item_id: int, db: Session = Depends(get_db)):
    row = db.get(Analysis, item_id)
    if not row:
        raise HTTPException(404, "Not found")
    db.delete(row)
    db.commit()
    return {"deleted": item_id}


@app.get("/api/profile")
def get_profile(db: Session = Depends(get_db)):
    return load_profile(db)


@app.put("/api/profile")
def put_profile(data: dict, db: Session = Depends(get_db)):
    return save_profile(db, data)
